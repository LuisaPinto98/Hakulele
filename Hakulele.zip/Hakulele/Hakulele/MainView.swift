//
//  MainView.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI

struct MainView: View {
    
    init() {
            UITabBar.appearance().barTintColor = UIColor.systemGray
        }
    
    var body: some View {
        
        TabView {
                    TunerView()
                        .tabItem {
                            Label("Tuner", systemImage: "tuningfork")
                        }

                    ChordsView()
                        .tabItem {
                            Label("Chords", systemImage: "music.note.list")
                        }
        }
    }
}

//struct MainView_Previews: PreviewProvider {
//    static var previews: some View {
//        MainView()
//    }
//}
