//
//  OnBoardingView.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI

struct OnBoardingView: View {
    
    @State var Banana : Bool = false
    
    var body: some View {
        
        NavigationView{
        
        
       
        ZStack{
        Rectangle()
            .frame(width: 447, height: 349)
            .foregroundColor(.accentColor)
            .cornerRadius(124)
            .padding(.bottom, 750.0)
            
        VStack {
            VStack{
                
                VStack{
                    Image(uiImage: UIImage(named: "logo-3")!)
                        .padding(.top, 0.0)
                        
                
                
                VStack{
                Text("Tuner & Chords List")
                    .font(Font.custom("BalooTamma-Regular", size: 24))
                    .font(Font.body.leading(.tight))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.top, 100.0)
                    .frame(height: 70)
                    
                 
                    Text("for your ukulele")
                        .font(Font.custom("BalooTamma-Regular", size: 24))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        
                }.padding(.bottom, 20.0)
                    .padding(.top, -60.0)
                    
                }.padding(.bottom, 125.0)
                    
                
                HStack{
                    VStack{
                        Image(systemName: "tuningfork")
                            .foregroundColor(Color("AccentColor"))
                            .font(.system(size: 35, weight: .regular))
                            .padding(.bottom, 50.0)
                        
                        Image(systemName: "music.note.list")
                            .foregroundColor(Color("AccentColor"))
                            .font(.system(size: 35, weight: .regular))
                            .padding(.bottom, 50.0)
                        
                        Image(systemName: "hand.point.up.left")
                            .foregroundColor(Color("AccentColor"))
                            .font(.system(size: 35, weight: .regular))
                        .padding(.top, 00.0)}
                   
                    
                    VStack(alignment: .leading, spacing: 10.0){
                        VStack(alignment: .leading, spacing: 10.0) {
                        Text("Intuitive Tuner")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .multilineTextAlignment(.leading)
                            
                        Text("Visualise the chords and tune your \nukulele easily in standard tuning.")
                            .fontWeight(.regular)
                            .foregroundColor(Color.gray)
                        .multilineTextAlignment(.leading)}
                        .padding(.bottom)
                        
                        VStack(alignment: .leading, spacing: 10.0) {
                            Text("Chords List")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .multilineTextAlignment(.leading)
                                
                            Text("Explore all the chords you can play \nwith your instrument.")
                                .fontWeight(.regular)
                                .foregroundColor(Color.gray)
                            .multilineTextAlignment(.leading)}
                        .padding(.bottom)
                        
                            
                            VStack(alignment: .leading, spacing: 10.0) {
                                Text("Learn Chords")
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                    .multilineTextAlignment(.leading)
                                    
                                Text("Using continuously this system you \nwill learn all the finger positions.")
                                    .fontWeight(.regular)
                                    .foregroundColor(Color.gray)
                                .multilineTextAlignment(.leading)}
                            .padding(.bottom)
                            
                    }
                    .padding(.leading)
                    
                }.padding(.top, -50.0)
                
                
                    
            }.padding(.bottom, 100.0)
            
            
            
            
                Button(action: {Banana.toggle()}) {
                Text("Let's start")
                    .font(Font.custom("BalooTamma-Regular", size: 24))
                    .padding(.horizontal, 115.0)
                    .padding(.bottom, 6.0)
                    .padding(.top, 10.0)
                        .foregroundColor(.white)
                        .background(Color.accentColor)
                        .cornerRadius(10)
            }
            .padding(.top, -50.0)
            .fullScreenCover(isPresented: $Banana) {MainView()}
            
        } .padding(.bottom, 80.0)
        }
        }
    }
    }


//struct OnBoardingView_Previews: PreviewProvider {
//    static var previews: some View {
//        OnBoardingView()
//    }
//}
