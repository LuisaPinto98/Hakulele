//
//  ChordsView.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI

struct ChordsView: View {
    
    var chords = ["Major", "6", "7", "Minor", "m6", "m7", "Sus2", "Sus4", "Maj7", "Dim7"]
    
        @State private var selectedChord = "Major"

    
    var body: some View {
        
        
        NavigationView{
            
            
            ZStack{
                Rectangle()
                    .frame(width: 414, height: 151)
                    .foregroundColor(.accentColor)
                    .padding(.bottom, 820.0)

                Text("Chords List")
                    .frame(width: 400)
                    .font(Font.custom("BalooTamma-Regular", size: 40))
                    .foregroundColor(.white)
                    .padding(.trailing, 175.0)
                    .padding(.bottom, 725.0)
                
                
                VStack{
                    
                    ZStack{
                        Group{
                            
                        Image(uiImage: UIImage(named: "box-16")!)
                            
                        Picker("Please choose a chord", selection: $selectedChord) {
                                   ForEach(chords, id: \.self) {
                                       Text($0)

                                   }
                            
                        }

                            
                            
                        }
                        .padding(.bottom, 570.0)
                       
                        
                    Image(uiImage: UIImage(named: selectedChord)!)
                            .padding(.top, 80.0)
                    }
                    
                    
                
                }
                
                
        }
            
            
            
    }
}
}


//struct ChordsView_Previews: PreviewProvider {
//    static var previews: some View {
//        ChordsView()
//    }
//}
