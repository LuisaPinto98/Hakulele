//
//  HakuleleApp.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI

@main
    
struct HakuleleApp: App {
    
    var body: some Scene {
        WindowGroup {
            
            OnBoardingView()
            
                }
            }
        }

   
