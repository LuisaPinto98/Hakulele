//
//  TunerView.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI
import AVFoundation


struct TunerView: View {
    
    @State var chordPlayer: AVAudioPlayer?
    @State var pushG = false
    @State var pushC = false
    @State var pushE = false
    @State var pushA = false
    var body: some View {
        
        NavigationView{
            
            
            ZStack{
                Rectangle()
                    .frame(width: 414, height: 151)
                    .foregroundColor(.accentColor)
                    .padding(.bottom, 820.0)
                
                Text("Tuner")
                    .font(Font.custom("BalooTamma-Regular", size: 40))
                    .foregroundColor(.white)
                    .padding(.trailing, 270.0)
                    .padding(.bottom, 725.0)
                
                ZStack{
                    
                    Image(uiImage: UIImage(named: "paletta-4")!)
                    .padding(.top, 60.0)
                    
                    
                    VStack(alignment:.center) {
                        
                        HStack(alignment:.center){
                      
                        Button(action: {
                            pushG = true
                            
                            impactMed.impactOccurred()

                            playSound(sound: "G", type: ".mp3")
                            
                        }) {
                        Text("G")
                            .font(Font.custom("BalooTamma-Regular", size: 35))
                            .padding(.horizontal, 25.0)
                            .padding(.bottom, 2.0)
                            .padding(.top, 8.0)
                            .foregroundColor(pushG ? Color.white: Color.gray)
                            .background(pushG ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                .cornerRadius(25)
                        }.frame(width: 80, height: 80)
                        
                            Spacer()
                            
                            
                         
                            Button(action: {
                                
                                pushE = true
                                
                                impactMed.impactOccurred()
                                
                                playSound(sound: "E", type: ".mp3")

                            }) {
                            Text("E")
                                .font(Font.custom("BalooTamma-Regular", size: 35))
                                .padding(.horizontal, 25.0)
                                .padding(.bottom, 2.0)
                                .padding(.top, 8.0)
                                .foregroundColor(pushE ? Color.white: Color.gray)
                                .background(pushE ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                    .cornerRadius(25)
                            }.frame(width: 80, height: 80)
                          
                        }.padding(.horizontal, 30)
                        
                        
                        
                        .padding(.vertical, 25.0)
                        
                        
                        
                        
                        
                        HStack(alignment:.center){
                            
                        Button(action: {
                            pushC = true
                            
                            impactMed.impactOccurred()
                            
                            playSound(sound: "C", type: ".mp3")
                            
                        }) {
                        Text("C")
                            .font(Font.custom("BalooTamma-Regular", size: 35))
                            .padding(.horizontal, 25.0)
                            .padding(.bottom, 2.0)
                            .padding(.top, 8.0)
                            .foregroundColor(pushC ? Color.white: Color.gray)
                            .background(pushC ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                .cornerRadius(25)
                        }.frame(width: 80, height: 80)
                            
                            Spacer()
                            
                            
                            
                            
                            Button(action: {
                                
                                pushA = true
                                
                                impactMed.impactOccurred()
                                
                                playSound(sound: "A", type: ".mp3")
                                
                            }) {
                            Text("A")
                                .font(Font.custom("BalooTamma-Regular", size: 35))
                                .padding(.horizontal, 25.0)
                                .padding(.bottom, 2.0)
                                .padding(.top, 8.0)
                                .foregroundColor(pushA ? Color.white: Color.gray)
                                .background(pushA ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                    .cornerRadius(25)
                        }.frame(width: 80, height: 80)
                            
                    }.padding(.horizontal, 40)
                            
                    
                    }.padding(.bottom, 220.0)
                    
                    
                    
                    }
                    
                }
            
                }
            }
    
   let impactMed = UIImpactFeedbackGenerator(style: .medium)
    
   func playSound(sound: String, type: String) {
       
        if let path = Bundle.main.path(forResource: sound, ofType: type) {
            do {
                chordPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
                chordPlayer?.play()
            } catch {
                print("Non funzionaaaaaa")
            }
        }
    }
    
        }
        


//struct TunerView_Previews: PreviewProvider {
//    static var previews: some View {
//        TunerView()
//    }
//}
