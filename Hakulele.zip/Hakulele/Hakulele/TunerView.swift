//
//  TunerView.swift
//  Hakulele
//
//  Created by Luisa Pinto on 10/12/21.
//

import SwiftUI
import AVFoundation


struct TunerView: View {
    
    @State var chordPlayer: AVAudioPlayer?
    @State var pushG = false
    @State var pushC = false
    @State var pushE = false
    @State var pushA = false
    @State var isPlaying:Bool = false
    @State var timer:Timer? = nil
    @State var time:Float64 = 0
    var body: some View {
        
        NavigationView{
            
            
            ZStack{
                
                Rectangle()
                    .frame(width: 414, height: 151)
                    .foregroundColor(.accentColor)
                    .padding(.bottom, 820.0)
                
                Text("Tuner")
                    .font(Font.custom("BalooTamma-Regular", size: 40))
                    .foregroundColor(.white)
                    .padding(.trailing, 270.0)
                    .padding(.bottom, 725.0)
                
                ZStack{
                    
                    Image(uiImage: UIImage(named: "paletta-4")!)
                    .padding(.top, 60.0)
                    
                    
                    VStack(alignment:.center) {
                       
                        
                        HStack(alignment:.center){
                      
                        Button(action: {
                            
                            pushG = true
                            pushA = false
                            pushC = false
                            pushE = false
                            
                            impactMed.impactOccurred()
                            isPlaying = true
                            playSound(sound: "G", type: ".mp3")
                            
                        }) {
                        Text("G")
                            .font(Font.custom("BalooTamma-Regular", size: 35))
                            .padding(.horizontal, 25.0)
                            .padding(.bottom, 2.0)
                            .padding(.top, 8.0)
                            .foregroundColor(pushG ? Color.white: Color.gray)
                            .background(pushG ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                .cornerRadius(25)
                        }.frame(width: 80, height: 80).onChange(of: isPlaying){newitem in
                          
                            if(isPlaying == false && pushG==true){
                                pushG=false
                            }
                            print(isPlaying)

                        }
                        
                            Spacer()
                            
                            
                         
                            Button(action: {
                                
                                pushE = true
                                
                                impactMed.impactOccurred()
                                pushG = false
                                pushA = false
                                pushC = false
                                isPlaying = true

                                playSound(sound: "E", type: ".mp3")

                            }) {
                            Text("E")
                                .font(Font.custom("BalooTamma-Regular", size: 35))
                                .padding(.horizontal, 25.0)
                                .padding(.bottom, 2.0)
                                .padding(.top, 8.0)
                                .foregroundColor(pushE ? Color.white: Color.gray)
                                .background(pushE ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                    .cornerRadius(25)
                            }.frame(width: 80, height: 80).onChange(of: isPlaying){newitem in
                                
                                if(isPlaying == false && pushE==true){
                                    pushE=false
                                }
                                print(isPlaying)

                            }
                          
                        }.padding(.horizontal, 30)
                        
                        
                        
                        .padding(.vertical, 25.0)
                        
                        
                        
                        
                        
                        HStack(alignment:.center){
                            
                        Button(action: {
                            pushC = true
                            pushG = false
                            pushA = false
                            pushE = false
                            impactMed.impactOccurred()
                            isPlaying = true

                            playSound(sound: "C", type: ".mp3")
                            
                        }) {
                        Text("C")
                            .font(Font.custom("BalooTamma-Regular", size: 35))
                            .padding(.horizontal, 25.0)
                            .padding(.bottom, 2.0)
                            .padding(.top, 8.0)
                            .foregroundColor(pushC ? Color.white: Color.gray)
                            .background(pushC ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                .cornerRadius(25)
                        }.frame(width: 80, height: 80).onChange(of: isPlaying){newitem in
                            
                            if(isPlaying == false && pushC==true){
                                pushC=false
                            }
                            print(isPlaying)

                        }
                            
                            Spacer()
                            
                            
                            
                            
                            Button(action: {
                                
                                pushA = true
                                pushG = false
                                pushC = false
                                pushE = false
                                impactMed.impactOccurred()
                                isPlaying = true

                                playSound(sound: "A", type: ".mp3")
                                
                            }) {
                            Text("A")
                                .font(Font.custom("BalooTamma-Regular", size: 35))
                                .padding(.horizontal, 25.0)
                                .padding(.bottom, 2.0)
                                .padding(.top, 8.0)
                                .foregroundColor(pushA ? Color.white: Color.gray)
                                .background(pushA ? .accentColor : Color(red: 216/255, green: 216/255, blue: 216/255, opacity: 1.0))
                                    .cornerRadius(25)
                        }.frame(width: 80, height: 80).onChange(of: isPlaying){newitem in
                            
                            if(isPlaying == false && pushA==true){
                                pushA=false
                            }
                            print(isPlaying)

                        }
                            
                    }.padding(.horizontal, 40)
                            
                    
                    }.padding(.bottom, 220.0)
                    
                    
                    
                    }
                    
                }
            
                }
            }
    
   let impactMed = UIImpactFeedbackGenerator(style: .medium)
    
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer!, successfully flag: Bool) {
        //You can stop the audio
        player.stop()

    }
    
    
   func playSound(sound: String, type: String) {
       chordPlayer?.stop()
       timer?.invalidate()
       time = 0
        if let path = Bundle.main.path(forResource: sound, ofType: type) {
            do {
                chordPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))

                chordPlayer?.play()
                let audioAsset = AVURLAsset.init(url: URL(fileURLWithPath: path), options: nil)
                                                        let duration = audioAsset.duration
                                                        let durationInSeconds = CMTimeGetSeconds(duration)
                                                        let formatter = DateComponentsFormatter()
                timer=Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true){temptimer in
                    time=time+0.3
                    
                    if (time >= durationInSeconds){
                        print(time)
                        chordPlayer?.stop()
                        isPlaying = false
                        timer?.invalidate()
                        timer = nil
                        time = 0
                    }
                }
            } catch {
                print("Non funzionaaaaaa")
            }
        }
    }
    
        }
        


//struct TunerView_Previews: PreviewProvider {
//    static var previews: some View {
//        TunerView()
//    }
//}
